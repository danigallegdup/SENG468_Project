import React from 'react';

function LoginPage() {
    return (
        <div>
            <div className='flex'>
                <h1>Login</h1>
                <p>This is the login page.</p>
            </div>
        </div>
        
    );
};
export default LoginPage;