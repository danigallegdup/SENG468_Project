import React from 'react';
import Layout from '@/components/layour/layout';

function TradePage() {
    return (
        <div>
            <Layout>
                <div className='flex'>
                    <h1>Trade</h1>
                    <p>This is the trade page.</p>
                </div>
            </Layout>
        </div>
        
    );
};

export default TradePage;