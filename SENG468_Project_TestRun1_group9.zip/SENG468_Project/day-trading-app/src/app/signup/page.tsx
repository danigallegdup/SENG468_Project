import React from 'react';

function SignUpPage() {
    return (
        <div>
            <div className='flex'>
                <h1>SignUp</h1>
                <p>This is the SignUp page.</p>
            </div>
        </div>
        
    );
};

export default SignUpPage;