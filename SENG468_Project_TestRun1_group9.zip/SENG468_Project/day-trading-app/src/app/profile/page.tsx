import React from 'react';
import Layout from '@/components/layour/layout';

function ProfilePage() {
    return (
        <div>
            <Layout>
                <div className='flex'>
                    <h1>Profile</h1>
                    <p>This is the profile page.</p>
                </div>
            </Layout>
        </div>
        
    );
};

export default ProfilePage;