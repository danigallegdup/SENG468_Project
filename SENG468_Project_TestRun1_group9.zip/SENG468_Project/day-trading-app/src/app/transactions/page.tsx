import React from 'react';
import Layout from '@/components/layour/layout';

function TransactionsPage() {
    return (
        <div>
            <Layout>
                <div className='flex'>
                    <h1>Transaction</h1>
                    <p>This is the transactions page.</p>
                </div>
            </Layout>
        </div>
        
    );
};

export default TransactionsPage;